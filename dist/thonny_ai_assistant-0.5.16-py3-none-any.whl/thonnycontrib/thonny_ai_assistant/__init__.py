"""thonny-ai-assistant plugin."""

from thonny import get_workbench
from thonnycontrib.thonny_ai_assistant.thonny_ai_assistant_tool import (
    AIChatView,
    thonny_ai_assistant,
)

def load_plugin():
    """Load plugin, register commands and toolbar buttons"""
    print("Loading thonny-ai-assistant plugin...")
    
    try:
        wb = get_workbench()
        
        wb.add_view(
            AIChatView,
            "AI助手",
            "se",
            default_position_key="se"
        )
        
        # Register command (with concise description)
        wb.add_command(
            command_id="thonny_ai_assistant",
            menu_name="tools",
            command_label="打开 thonny-ai-assistant",
            handler=thonny_ai_assistant,
            include_in_toolbar=True,  # Add to toolbar for quick access
            caption="AI助手"
        )
        
        # Add API Key settings menu item
        wb.add_command(
            command_id="thonny_ai_assistant_settings",
            menu_name="tools",
            command_label="thonny-ai-assistant 设置",
            handler=lambda: AIChatView.show_api_key_dialog(),
            include_in_toolbar=False,
            caption="管理 AI 模型供应商、API 地址和 API Key"
        )
        
        print("thonny-ai-assistant plugin loaded successfully.")
    except Exception as e:
        print(f"Error loading thonny-ai-assistant plugin: {e}")
        import traceback
        traceback.print_exc()
